var carrito = [];

function agregarAlCarrito(nombre, precio) {
    var productoExistente = carrito.find(function(item) {
        return item.nombre === nombre;
    });

    if (productoExistente) {
        productoExistente.cantidad++;
    } else {
        carrito.push({ nombre: nombre, precio: precio, cantidad: 1 });
    }
    actualizarCarrito();
}

function actualizarCarrito() {
    var carritoContenido = document.getElementById('carritoContenido');
    var totalPagar = document.getElementById('totalPagar');
    var total = 0;

    carritoContenido.innerHTML = '';

    carrito.forEach(function(producto) {
        var tr = document.createElement('tr');
        var tdNombre = document.createElement('td');
        var tdPrecio = document.createElement('td');
        var tdCantidad = document.createElement('td');
        var tdTotal = document.createElement('td');

        tdNombre.textContent = producto.nombre;
        tdPrecio.textContent = '$' + producto.precio.toFixed(2);
        tdCantidad.textContent = producto.cantidad;
        tdTotal.textContent = '$' + (producto.precio * producto.cantidad).toFixed(2);

        tr.appendChild(tdNombre);
        tr.appendChild(tdPrecio);
        tr.appendChild(tdCantidad);
        tr.appendChild(tdTotal);

        carritoContenido.appendChild(tr);

        total += producto.precio * producto.cantidad;
    });

    totalPagar.textContent = '$' + total.toFixed(2);
}

function mostrarCarrito() {
    document.getElementById('carritoModal').style.display = 'block';
    window.addEventListener('keydown', cerrarCarritoConEsc);
}

function cerrarCarrito() {
    document.getElementById('carritoModal').style.display = 'none';
    window.removeEventListener('keydown', cerrarCarritoConEsc);
}

function cerrarCarritoConEsc(event) {
    if (event.key === 'Escape') {
        cerrarCarrito();
    }
}
function enviarPorCorreo() {
    var productosTexto = '';

    carrito.forEach(function(producto) {
        productosTexto += `Nombre: ${producto.nombre}, Precio: $${producto.precio.toFixed(2)}, Cantidad: ${producto.cantidad}\n`;
    });

    var url = `https://formspree.io/f/xjvdnbkl`;
    var form = document.createElement('form');
    form.setAttribute('action', url);
    form.setAttribute('method', 'POST');

    var productosInput = document.createElement('input');
    productosInput.setAttribute('type', 'hidden');
    productosInput.setAttribute('name', 'productos');
    productosInput.setAttribute('value', productosTexto);

    form.appendChild(productosInput);

    document.body.appendChild(form);
    form.submit();

    document.body.removeChild(form);

    alert('Compra realizada exitosamente, te contactaremos muy pronto.');
}

const clickableImages = document.querySelectorAll('.clickable-image');
const popups = document.querySelectorAll('.popup');
const closeButtons = document.querySelectorAll('.close-button');

clickableImages.forEach((image, index) => {
    image.addEventListener('click', () => {
        openPopup(index);
    });

    closeButtons[index].addEventListener('click', () => {
        closePopup(index);
    });
    
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closePopup(index);
        }
    });
});

function openPopup(index) {
    popups[index].style.display = 'flex';
}

function closePopup(index) {
    popups[index].style.display = 'none';
}
